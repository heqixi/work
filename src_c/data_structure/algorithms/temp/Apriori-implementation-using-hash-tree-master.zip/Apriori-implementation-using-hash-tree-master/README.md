# Apriori-implementation-using-hash-tree

The goal of this assignment is to generate interesting association rules using apriori algorithm and support counting using Hash tree Data Structure.
