# FpTree
my C++ implementation of  Mining Frequent Patterns using classical FP-tree growth method

